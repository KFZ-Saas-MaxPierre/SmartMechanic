import Link from "next/link";

const NAV_ITEMS = [
  { href: "/calendar", label: "Kalender" },
  { href: "/customers", label: "Kunden" },
  { href: "/vehicles", label: "Fahrzeuge" },
  { href: "/mechanics", label: "Mechaniker" },
  { href: "/lifts", label: "Hebebühnen" },
  { href: "/work-types", label: "Arbeitsarten" },
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen">
      <header className="border-b border-gray-200 bg-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link href="/" className="text-lg font-semibold text-brand-700">
            Werkstattlotse
          </Link>
          <nav className="flex gap-1">
            {NAV_ITEMS.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-md px-3 py-2 text-sm font-medium text-gray-600 hover:bg-brand-50 hover:text-brand-700"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-6 py-8">{children}</main>
    </div>
  );
}
