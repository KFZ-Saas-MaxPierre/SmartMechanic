import { prisma } from "@/lib/db";
import { PageHeader } from "@/components/ui/PageHeader";
import { Table, Th, Td, EmptyState } from "@/components/ui/Table";

const WEEKDAY_LABELS = ["Mo", "Di", "Mi", "Do", "Fr", "Sa", "So"];

export default async function MechanicsPage() {
  const mechanics = await prisma.mechanic.findMany({
    include: { shifts: true },
    orderBy: { name: "asc" },
  });

  return (
    <div>
      <PageHeader
        title="Mechaniker"
        description="Alle Mechaniker mit ihren wöchentlichen Arbeitszeiten."
      />
      <Table>
        <thead>
          <tr>
            <Th>Name</Th>
            <Th>Status</Th>
            <Th>Arbeitszeiten</Th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {mechanics.map((mechanic) => (
            <tr key={mechanic.id}>
              <Td>{mechanic.name}</Td>
              <Td>{mechanic.active ? "Aktiv" : "Inaktiv"}</Td>
              <Td>
                {mechanic.shifts.length === 0
                  ? "–"
                  : mechanic.shifts
                      .sort((a, b) => a.weekday - b.weekday)
                      .map(
                        (shift) =>
                          `${WEEKDAY_LABELS[shift.weekday]} ${shift.startTime}–${shift.endTime}`
                      )
                      .join(", ")}
              </Td>
            </tr>
          ))}
        </tbody>
      </Table>
      {mechanics.length === 0 && <EmptyState label="Noch keine Mechaniker angelegt." />}
    </div>
  );
}
