import { prisma } from "@/lib/db";
import { PageHeader } from "@/components/ui/PageHeader";
import { Table, Th, Td, EmptyState } from "@/components/ui/Table";

export default async function LiftsPage() {
  const lifts = await prisma.lift.findMany({ orderBy: { name: "asc" } });

  return (
    <div>
      <PageHeader
        title="Hebebühnen"
        description="Alle Hebebühnen der Werkstatt."
      />
      <Table>
        <thead>
          <tr>
            <Th>Name</Th>
            <Th>Status</Th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {lifts.map((lift) => (
            <tr key={lift.id}>
              <Td>{lift.name}</Td>
              <Td>{lift.active ? "Aktiv" : "Inaktiv"}</Td>
            </tr>
          ))}
        </tbody>
      </Table>
      {lifts.length === 0 && <EmptyState label="Noch keine Hebebühnen angelegt." />}
    </div>
  );
}
