import { prisma } from "@/lib/db";
import { PageHeader } from "@/components/ui/PageHeader";
import { Table, Th, Td, EmptyState } from "@/components/ui/Table";

export default async function VehiclesPage() {
  const vehicles = await prisma.vehicle.findMany({
    include: { customer: true },
    orderBy: { createdAt: "desc" },
  });

  return (
    <div>
      <PageHeader
        title="Fahrzeuge"
        description="Alle erfassten Fahrzeuge mit zugehörigem Kunden."
      />
      <Table>
        <thead>
          <tr>
            <Th>Kennzeichen</Th>
            <Th>Marke / Modell</Th>
            <Th>Kunde</Th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {vehicles.map((vehicle) => (
            <tr key={vehicle.id}>
              <Td>{vehicle.licensePlate}</Td>
              <Td>
                {vehicle.make} {vehicle.model}
              </Td>
              <Td>{vehicle.customer.name}</Td>
            </tr>
          ))}
        </tbody>
      </Table>
      {vehicles.length === 0 && <EmptyState label="Noch keine Fahrzeuge angelegt." />}
    </div>
  );
}
