import { prisma } from "@/lib/db";
import { PageHeader } from "@/components/ui/PageHeader";
import { Table, Th, Td, EmptyState } from "@/components/ui/Table";
import { AppointmentSuggestions } from "@/components/AppointmentSuggestions";

export default async function CalendarPage() {
  const [appointments, workTypes] = await Promise.all([
    prisma.appointment.findMany({
      where: { startsAt: { gte: new Date() } },
      include: { vehicle: { include: { customer: true } }, workType: true, mechanic: true, lift: true },
      orderBy: { startsAt: "asc" },
      take: 20,
    }),
    prisma.workType.findMany({ orderBy: { name: "asc" } }),
  ]);

  return (
    <div className="flex flex-col gap-8">
      <PageHeader
        title="Kalender"
        description="Kommende Termine und automatische Terminvorschläge."
      />

      <AppointmentSuggestions
        workTypes={workTypes.map((wt) => ({
          id: wt.id,
          name: wt.name,
          durationMinutes: wt.durationMinutes,
        }))}
      />

      <div>
        <h2 className="mb-3 text-base font-semibold text-gray-900">
          Nächste Termine
        </h2>
        <Table>
          <thead>
            <tr>
              <Th>Zeit</Th>
              <Th>Fahrzeug / Kunde</Th>
              <Th>Arbeitsart</Th>
              <Th>Mechaniker</Th>
              <Th>Hebebühne</Th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {appointments.map((appt) => (
              <tr key={appt.id}>
                <Td>
                  {appt.startsAt.toLocaleString("de-AT", {
                    weekday: "short",
                    day: "2-digit",
                    month: "2-digit",
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </Td>
                <Td>
                  {appt.vehicle.licensePlate} · {appt.vehicle.customer.name}
                </Td>
                <Td>{appt.workType.name}</Td>
                <Td>{appt.mechanic.name}</Td>
                <Td>{appt.lift?.name ?? "–"}</Td>
              </tr>
            ))}
          </tbody>
        </Table>
        {appointments.length === 0 && (
          <EmptyState label="Keine anstehenden Termine." />
        )}
      </div>
    </div>
  );
}
